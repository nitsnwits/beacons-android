package cmpe295.sjsu.edu.salesman;

/**
 * Created by Rucha on 6/20/15.
 */
public class NameWrapper {

    public Name name;

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }
}
