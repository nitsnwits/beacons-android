package cmpe295.sjsu.edu.salesman.fragments;

import android.app.Fragment;

/**
 * Created by jijhaver on 6/22/15.
 */
public class StoreMapFragment extends Fragment {
}
