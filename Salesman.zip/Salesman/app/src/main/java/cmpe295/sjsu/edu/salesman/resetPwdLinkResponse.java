package cmpe295.sjsu.edu.salesman;

/**
 * Created by Rucha on 6/28/15.
 */
public class resetPwdLinkResponse {

    public String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
