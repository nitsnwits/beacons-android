package cmpe295.sjsu.edu.salesman;

/**
 * Created by Rucha on 6/27/15.
 */
public class resetPwdResponse {

    public String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}


