# beacons-android
CMPE 295A Context based product marketing using beacons android application
